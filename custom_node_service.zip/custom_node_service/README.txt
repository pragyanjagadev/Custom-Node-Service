Installation
============

This module is dependent on Services module.To install this module keep the module inside site->all->defaults folder and enable it from module section.

Settings 
======================

This module allows to set API keys in site information page.Please refer attached screenshot.
To retrieve node details, create a new service by clicking on Structure -> Services -> Add.Please refer attched "service_resource_setting" and select "Custom Schema" and save the service.
Copy the URL from the "Site Information" page and try accessing the details of the specified node.